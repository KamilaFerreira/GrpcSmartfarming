package com.github.kamila.grpc;

import com.proto.temperature.*;
import io.grpc.stub.StreamObserver;

import java.util.Random;


public class temperatureServiceImpl extends TemperatureServiceGrpc.TemperatureServiceImplBase {
    Random random = new Random();

    //Unary Call
    @Override
    public void temperature(TemperatureRequest request, StreamObserver<TemperatureResponse> responseObserver) {
        TemperatureResponse temperatureResponse = TemperatureResponse.newBuilder()

                .setResultTemper(request.getTemper())
                .build();

        responseObserver.onNext(temperatureResponse); //send back the response to the client

        responseObserver.onCompleted(); //complete the rpc call

    }


    //Server Streaming
    /*@Override
    public void temperatureManyTimes(TemperatureManyTimesRequest request, StreamObserver<TemperatureManyTimesResponse> responseObserver) {

        Random random = new Random();
        try{
            for(int i = 0; i < 5; i++){ // the server will send the last 5 temperature to the client
                int resultTemper = (random.nextInt(30));
                TemperatureManyTimesResponse response = TemperatureManyTimesResponse.newBuilder()
                        .setResultTemper2(resultTemper+i)
                        .build();

                responseObserver.onNext(response);
                Thread.sleep(1000L);
            }
        }catch (InterruptedException e){
            e.printStackTrace();
        }finally {
            responseObserver.onCompleted();
        }
    }*/

    //Client Streaming
    /*@Override
    public StreamObserver<TemperatureAverageRequest> temperatureAverage(StreamObserver<TemperatureAverageResponse> responseObserver) {

        StreamObserver<TemperatureAverageRequest> requestObserver = new StreamObserver<TemperatureAverageRequest>() {
            int sum = 0;
            int count = 0;
            @Override
            public void onNext(TemperatureAverageRequest value) { //here will be set data from the client
                sum += value.getTemper3();
                count += 1;

            }

            @Override
            public void onError(Throwable t) {

            }

            @Override
            public void onCompleted() {
                //compute the average
                double average =(double) sum/ count;
                responseObserver.onNext(
                        TemperatureAverageResponse.newBuilder()
                        .setAverage(average)
                        .build()
                );

                responseObserver.onCompleted();

            }
        };
     return requestObserver;
    }*/

    //BIDirectional Temperature
    @Override
    public StreamObserver<HighestTemperatureRequest> highestTemperature(StreamObserver<HighestTemperatureResponse> responseObserver) {


        return new StreamObserver<HighestTemperatureRequest>() {
            int currentHighest = 0;

            @Override
            public void onNext(HighestTemperatureRequest value) {
                int currentTemper = value.getTemper4(); //checks the highest temperature
                if (currentTemper > currentHighest) {
                    currentHighest = currentTemper;
                    responseObserver.onNext(
                            HighestTemperatureResponse.newBuilder()
                                    .setHighest(currentHighest)
                                    .build()
                    );
                } else {
                    //nothing changes
                }

            }

            @Override
            public void onError(Throwable t) {
                responseObserver.onCompleted(); //just close the request

            }

            @Override
            public void onCompleted() {
                responseObserver.onNext(
                        HighestTemperatureResponse.newBuilder()
                                .setHighest(currentHighest) //here is the last highest temperature
                                .build());
                //server is done sending data
                responseObserver.onCompleted();//send back the request to the client

            }
        };
    }
}







