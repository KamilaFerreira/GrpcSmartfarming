package com.github.kamila.grpc;

import io.grpc.Server;
import io.grpc.ServerBuilder;

import java.io.IOException;

public class temperatureServer {
    public static void main(String[] args) throws IOException, InterruptedException {
        System.out.println("Server is running");
        Server server = ServerBuilder.forPort(50055)
                .addService(new temperatureServiceImpl()) //service implemented
                .build();

        server.start();

        Runtime.getRuntime().addShutdownHook(new Thread( () -> {
            System.out.println("receive shutdown request");
            server.shutdown();
            System.out.println("Succesfully stopped the server");
        } )); // when a shutDown is requested, this code shutsdown

        server.awaitTermination(); //finishes the server
    }
}
