package com.github.kamila.grpc;

import com.proto.temperature.HighestTemperatureRequest;
import com.proto.temperature.HighestTemperatureResponse;
import com.proto.temperature.TemperatureServiceGrpc;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;

import javax.swing.*;
import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;


public class temperatureClient {
    //private static TemperatureServiceGrpc.TemperatureServiceBlockingStub;



    public static void main(String[] args) throws InterruptedException {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50055)
                .usePlaintext()
                .build();
        //TemperatureServiceGrpc.TemperatureServiceStub asyncClient = TemperatureServiceGrpc.newStub(channel);

        Random random = new Random();
        //Unary Service
        //created a temperature service
        /*TemperatureServiceGrpc.TemperatureServiceBlockingStub temperClient = TemperatureServiceGrpc.newBlockingStub(channel);

        //Instruction to client type the number 1 to request the current temperature
        int number1 = Integer.parseInt(JOptionPane.showInputDialog(null, "Please type the number - 1 - to request the current temperature"));

        if (number1 == 1) {

            TemperatureRequest request = TemperatureRequest.newBuilder()
                    .setTemper(random.nextInt(50)) //generating random number top attend the request
                    .build();

            //call the rpc and get back the response
            TemperatureResponse response = temperClient.temperature(request);
               //printing the temperature to the client
            JOptionPane.showMessageDialog(null,"The current temperature is:  " + request.getTemper()  +  " degrees");

        }else {//handling errors
               JOptionPane.showMessageDialog(null,"This is not a valid number, please type the number 1 to request the current temperature");

        }*/
        // Streaming Server

        /*TemperatureServiceGrpc.TemperatureServiceBlockingStub temperClient = TemperatureServiceGrpc.newBlockingStub(channel);
        //input from the client
         int number2 = Integer.parseInt((JOptionPane.showInputDialog(null,"Please type the number - 2 - to request the past 5-hour-temperature")));

         if (number2 == 2) {

             TemperatureManyTimesRequest temperatureManyTimesRequest =
                     TemperatureManyTimesRequest.newBuilder()
                             .setTemper2(random.nextInt())
                             .build();


             temperClient.temperatureManyTimes(temperatureManyTimesRequest)
                     .forEachRemaining(temperatureManyTimesResponse -> {


                         JOptionPane.showMessageDialog(null," The last 5-hour-temperature are: " + temperatureManyTimesResponse.getResultTemper2() + " degrees." +
                                 "Press Ok to check the remaining temperature");
                     });
         } else {
             JOptionPane.showMessageDialog(null,"This is not a valid number, please type the number 2 to request the past 5-hour-temperature");
             //System.out.println("This is not a valid number, please type the number 2 to request the past 5-hour-temperature");
         }*/

        //Client Streaming Call
        /*TemperatureServiceGrpc.TemperatureServiceStub asyncClient = TemperatureServiceGrpc.newStub(channel);
        CountDownLatch latch = new CountDownLatch(1);

        StreamObserver<TemperatureAverageRequest> requestObserver = asyncClient.temperatureAverage(new StreamObserver<TemperatureAverageResponse>() {
            @Override
            public void onNext(TemperatureAverageResponse value) {
                System.out.println(value.getAverage());
                //JOptionPane.showMessageDialog(null, " The average temperature is :" + value.getAverage() + "degrees");


            }


            @Override
            public void onError(Throwable t) {

            }

            @Override
            public void onCompleted() {

                latch.countDown();

            }
        });


        int number12 = Integer.parseInt(JOptionPane.showInputDialog(null, "Type a number of temperature would like to check the average"));
        if (number12 > 0) {
            for (int i = 0; i < 20; i++) {
                requestObserver.onNext(TemperatureAverageRequest.newBuilder()
                        .setTemper3(i)
                        .build());
            }


            requestObserver.onCompleted();
            try {
                latch.await(3, TimeUnit.SECONDS);
            }catch (InterruptedException e){
                e.printStackTrace();
            }
            System.out.println("Shutting down channel");
            channel.shutdown();
        }

        else

    {
        JOptionPane.showMessageDialog(null, "The number must be higher than 0");


        requestObserver.onCompleted();
    }*/

        //latch.await(3, TimeUnit.SECONDS);
        //System.out.println("Shutting down channel");
        //channel.shutdown();


        //Bidirectional Streaming call
        TemperatureServiceGrpc.TemperatureServiceStub asyncClient = TemperatureServiceGrpc.newStub(channel);
        CountDownLatch latch = new CountDownLatch(1);
        StreamObserver<HighestTemperatureRequest> requestObserver = asyncClient.highestTemperature(new StreamObserver<HighestTemperatureResponse>() {
            @Override
            public void onNext(HighestTemperatureResponse value) {
                int highest24 = Integer.parseInt(JOptionPane.showInputDialog(null, "Type 1 to check the Highest temperature for the last 24 hours"));
                if (highest24 == 1) {
                    JOptionPane.showMessageDialog(null, "The highest temperature is : " + value.getHighest());
                } else {
                    JOptionPane.showMessageDialog(null, "This is not a valid Number");
                }
            }

            @Override
            public void onError(Throwable t) {
                latch.countDown(); //client is done sending the request

            }

            @Override
            public void onCompleted() {
                System.out.println("Server is done sending messages");

            }
        });


        Arrays.asList(30, 26, 24, 28).forEach( //  made up temperatures were send to the server in order to check to highest temperature
                temper4 -> {
                    System.out.println("Sending, press OK to continue " + temper4);
                    requestObserver.onNext(HighestTemperatureRequest.newBuilder()
                            .setTemper4(temper4)
                            .build());
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
        );
        requestObserver.onCompleted();
        try {
            latch.await(3, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();

            System.out.println("Shutting down channel");
            channel.shutdown();
        }



    }
}








